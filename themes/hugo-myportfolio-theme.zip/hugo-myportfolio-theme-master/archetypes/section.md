---
title: "<SECTION_NAME>"
#showsections: <BOOL>                #default: true
sections_title: "<SUBSECTIONS_TYPE>"
#sections_order: "<METADATA_FIELD>"  #default: "title"
#sections_order_reverse: <BOOL>      #default: false
#showposts: <BOOL>                   #default: true
posts_title: "<POSTS_TYPE>"
#posts_order: "<METADATA_FIELD>"     #default: "date"
#posts_order_reverse: <BOOL>         #default: true
#showbrothers: <BOOL>                #default: true
---
