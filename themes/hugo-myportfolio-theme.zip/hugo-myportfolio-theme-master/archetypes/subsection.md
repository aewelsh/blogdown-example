---
# Template for subsections, such as a company or a category.
title: "<COMPANY_NAME>"
subtitle: "<POSITION>"
#startDate: "YYYY-MM-DD"
#endDate: "YYYY-MM-DD"
#image: "<IMAGE_FILE>"
#image_copyright: "<TEXT>"
#small_image: "<IMAGE_FILE>"
#small_url: "<URL>"
#showposts: <BOOL>               #default: true
posts_title: "<POSTS_TYPE>"
#posts_order: "<METADATA_FIELD>" #default: "date"
#posts_order_reverse: <BOOL>     #default: true
#showbrothers: <BOOL>            #default: true
---

<b>DESCRIPTION</b><br>
...<br>
