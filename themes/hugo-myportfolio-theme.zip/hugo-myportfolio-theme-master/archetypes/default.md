---
# Template for projects.
title: "<PROJECT_NAME>"
subtitle: "<CATCH_PHRASE>"
#image: "<IMAGE_FILE>"
#small_image: "<IMAGE_FILE>"
#small_url: "<URL>"
categories: [ "<CATEGORY>" ]
tags: [ "<TAG>" ]
#images_directory; "images"
#images_static: "false"
#images_copyright: "<COPYRIGHT>"
##For "image" image files:
# (Only required for caption and specific copyrights)
#images:
#- src: "<IMAGE_FILE>"
#  title: "<LEGEND>"
#  copyright: "<COPYRIGHT>"
##For "logo" image files:
#resources:
#- src: "logos/<IMAGE_FILE>"
#  title: "<TOOLTIP>"
---

<b>CLIENT:</b> ...<br>

<b>DESCRIPTION:</b><br>
...<br>

<b>ROLE:</b><br>
...<br>
