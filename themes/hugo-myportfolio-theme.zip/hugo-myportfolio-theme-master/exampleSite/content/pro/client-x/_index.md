+++
title = "Client X"
subtitle = "Freelance"
startDate = "2016-08-01"
endDate = "2016-12-01"
small_image = "comp3.png"
posts_title = "PROJECTS:"
+++

Some freelance work for a specific client.
