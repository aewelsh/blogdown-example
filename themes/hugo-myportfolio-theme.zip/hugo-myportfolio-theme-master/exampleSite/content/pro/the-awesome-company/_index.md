+++
title = "THE AWESOME COMPANY"
startDate = "2010-06-01"
endDate = "2012-02-01"
#image = "hero.jpg"
small_image = "comp1.png"
small_url = "https://some_url.url"
posts_title = "PROJECTS:"
+++

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus auctor, ex sit amet condimentum placerat, neque dolor facilisis purus, in elementum ex urna at ante. Praesent turpis leo, auctor at justo vel, dignissim imperdiet tellus. Vivamus nec orci luctus, pharetra mauris eget, tristique ligula. Integer elit lorem, blandit ut eros et, efficitur aliquet dui. Aenean sed orci lorem. Nulla facilisi. Cras sollicitudin odio eu erat sollicitudin, sit amet volutpat risus condimentum. Praesent blandit vitae magna pellentesque vestibulum. Nam et facilisis lacus. Proin malesuada est at tellus semper, vel porttitor massa malesuada.
Nulla at quam sit amet lectus interdum blandit. Phasellus dolor velit, ullamcorper id justo vitae, hendrerit dictum elit. Curabitur cursus efficitur ex, in volutpat tortor. Nunc venenatis, mauris nec ultrices vulputate, libero ante volutpat ante, sit amet efficitur metus neque a diam. Nulla facilisi. Nam porta sagittis magna, et congue mi venenatis eu. Duis luctus, nisl sit amet volutpat semper, lorem quam congue tortor, eget finibus justo mi sit amet elit. Sed et nisl quis ante rhoncus vehicula vitae a lectus. Pellentesque mollis eu velit eget sodales.
