---
title: "A Different Project"
subtitle: "With a subtitle."
small_image: "draw4.jpg"
categories: [ "IT", "art" ]
tags: [ "bundle", "music", "drawing" ]
---

Not much more to say, but it is as a "bundle" post.
