---
title: "A Weird Project"
subtitle: "Freestyle weirdness"
categories: [ "art", "IT" ]
tags: [ "bundle", "drawing" ]
images:
- src: "draw2.jpg"
  title: "Weird drawing"
  copyright: "DEREK SEVERIN"
---
