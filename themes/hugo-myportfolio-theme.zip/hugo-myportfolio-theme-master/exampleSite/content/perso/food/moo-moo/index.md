---
title: "MOO MOO"
subtitle: "Some photos of food at Moo Moo Steak House"
image: "images/moo_moo_seafood.jpg"
small_image: "small.png"
small_url: "https://www.moobeefsteak.com.vn/"
categories: [ "food", "vietnam" ]
tags: [ "seafood", "foie gras", "western", "salad" ]
images:
- src: "moo_moo_foie_gras.jpg"
  title: "Foie gras"
- src: "moo_moo_salad.jpg"
  title: "Salad"
- src: "moo_moo_seafood.jpg"
  title: "Seafood"
---

Description:
Some food from Moo Moo Steak house in Saigon.
