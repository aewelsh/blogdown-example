---
title: "Vietnam"
subtitle: "Some vietnamese dishes"
image: "pho99_fried_pho.jpg"
categories: [ "food", "vietnam" ]
tags: [ "soup", "pho", "asian" ]
images:
- src: "pho99_fried_pho.jpg"
  title: "Fried pho"
- src: "ut_hue.jpg"
  title: "Bun Bo Hue"
- src: "royal_lunch.jpg"
  title: "Cheap lunch"
  copyright: "my photo"
---

Description:
Food from different places in Saigon.
