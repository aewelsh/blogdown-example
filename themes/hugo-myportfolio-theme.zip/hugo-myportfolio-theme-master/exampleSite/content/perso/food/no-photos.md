---
title: "Some post"
subtitle: "Post with no photo"
categories: [ "food" ]
tags: [ "western" ]
---

Description:
This is just a simple post with no photos...
Hence it doesn't have to be a bundle and can be a simple "md" file.
