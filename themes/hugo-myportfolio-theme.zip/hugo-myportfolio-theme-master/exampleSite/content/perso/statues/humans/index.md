---
title: "Human Statues"
subtitle: "Some statues of humans."
small_image: "small.jpg"
categories: [ "art", "statue", "vietnam" ]
tags: [ "asian", "human" ]
---

Description:
Statues from Cham museum in Da Nang, Vietnam.
