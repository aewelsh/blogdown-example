---
title: "Other Statues"
subtitle: "Some statues."
image: "4.jpg"
categories: [ "statue", "vietnam" ]
tags: [ "asian" ]
---

Description:
Statues from Cham museum in Da Nang, Vietnam.
