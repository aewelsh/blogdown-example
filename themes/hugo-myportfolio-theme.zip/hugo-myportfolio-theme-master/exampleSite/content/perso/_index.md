---
title: "PERSONAL"
sections_title: "Categories"
#sections_order: "weight"
#sections_order_reverse: false
posts_title: "Projects"
---

Here are the different categories...
