---
title: "Random"
subtitle: "A random drawing"
categories: [ "art" ]
tags: [ "drawing", "asian" ]
images:
- src: "flower_scene.jpg"
  title: "A flower seller in HCMC"
---

Drawing(s)...
