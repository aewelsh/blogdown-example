---
title: "Drawings"
subtitle: "Some drawings ..."
cover_image: "gears_cover.jpg"
small_image: "weird-small.jpg"
posts_title: "Projects"
#weight: 1
---

A drawing is worth a thousand words...
